import React, { Component } from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { DrawerNavigator } from 'react-navigation';

import MainPage from './MainPage';

class App extends Component {
  render() {
    return <MainPage />;
  }
}
export default App;
